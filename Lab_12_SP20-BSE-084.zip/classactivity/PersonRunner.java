package classactivity;

import java.util.ArrayList;

public class PersonRunner {

    public static void main(String[] args) {
        Student[] student = new Student[5];
        student[0] = new Student("Sohan", "123");
        student[1] = new Student("Sam", "121");
        student[2] = new Student("Raahim", "134");
        student[0].associate();
        student[1].associate();
        student[2].associate();

        System.out.println("\n");

        Teacher[] teacher = new Teacher[5];
        teacher[0] = new Teacher("Behjat", "201");
        teacher[1] = new Teacher("Isma", "208");
        teacher[2] = new Teacher("Talha", "211");
        teacher[0].associate();
        teacher[1].associate();
        teacher[2].associate();

        System.out.println("\n");

        /**
         * This is a test runner only. Below this part you will find array and
         * arraylist runner.
         */
        /**
         * HumanResource hr = new HumanResource(); hr.addEntity(student[0]);
         * hr.addEntity(student[1]); hr.addEntity(student[2]);
         * hr.addEntity(teacher[0]); hr.addEntity(teacher[1]);
         * hr.addEntity(teacher[2]); hr.print(); System.out.println("Before
         * deletion"); System.out.println("\n");
         *
         * hr.delete("201"); hr.delete("121");
         *
         * System.out.println("After deletion"); hr.print();
         *
         */
        
        /**
         * ABOVE IS TEST RUNNER ONLY. 
         * REAL IMPLEMENTATION IS BELOW.
         */
        
        
        
        /**
          * The runner below is of array. Array implementation runner.
         */
        /**
         * HumanResource hr = new HumanResource(); hr.adden(student[0]);
         * hr.adden(student[1]); hr.adden(student[2]);
         *
         * hr.adden(teacher[0]); hr.adden(teacher[1]); hr.adden(teacher[2]);
         * System.out.println(hr.toString()); System.out.println("Before
         * deletion"); System.out.println("\n"); hr.delete(0); hr.delete(1);
         *
         * System.out.println("After deletion");
         * System.out.println(hr.toString());
        *
         */
        
        
        
        /**
         * ArrayList runner implementation. Below is the runner of ArrayList.
         */
        HumanResource humanresource = new HumanResource();
        humanresource.addEn(student[0]);
        humanresource.addEn(student[1]);
        humanresource.addEn(student[2]);
        humanresource.addEn(teacher[0]);
        humanresource.addEn(teacher[1]);
        humanresource.addEn(teacher[2]);
        System.out.println(humanresource.toString());
        System.out.println("Before deletion");
        System.out.println("\n");
        humanresource.delete(1);
        humanresource.delete(2);

        System.out.println("After deletion");
        System.out.println(humanresource.toString());

    }

}
