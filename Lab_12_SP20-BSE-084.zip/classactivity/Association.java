
package classactivity;

public interface Association {
   public void associate();
}
