
package classactivity;

import java.util.Scanner;


public class Teacher extends Person implements Association{
    private String designation;
    private String department;

   public Teacher(String name, String id) {
        super(name, id);
    }

  
    
 //   public Teacher(String id, String name,String designation,String department) {
   //     super(id, name);
     //   this.designation=designation;
       // this.department=department;
        
    //}

    @Override
    public String getId() {
        return id;
    }
    public String getDesignation() {
        return designation;
    }

   
    public void setDesignation(String designation) {
        this.designation = designation;
    }

  
    public String getDepartment() {
        return department;
    }

    
    public void setDepartment(String department) {
        this.department = department;
    }
    
    
    @Override
    public String toString(){
        return "Teacher ["+super.toString()+"\t"+String.format("Designation = %s , Department = %s",designation,department)+"]";
    }

    @Override
    public void associate() {
         Scanner kb = new Scanner(System.in);
        System.out.print("Enter Teacher Designation = ");
        this.designation=kb.nextLine();
        System.out.print("Enter Teacher Department = ");
        this.department=kb.nextLine();
    }
    
}
