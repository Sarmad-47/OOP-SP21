
package lab11_labtask;

public interface Shape {
    public double area();
}
