
package lab11_labtask;


public class ShapesRunner {
    public static void main(String[] args) {
        Shape[] shapes=new Shape[5];
        shapes[0]=new Circle(5.7);
        shapes[1]=new Circle(8.4);
        shapes[2]=new Rectangle(20,12);
        shapes[3]=new Triangle(10,5);
        shapes[4]=new Triangle(13,3);
        
           double arr_area[] = CalculateArea.Arr_Area(shapes);
            for(double area: arr_area) {
                System.out.println(area);
            }
    }
    
}
