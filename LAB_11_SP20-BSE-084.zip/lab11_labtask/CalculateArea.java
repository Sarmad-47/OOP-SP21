package lab11_labtask;

public class CalculateArea {

    public static double[] Arr_Area(Shape[] shapes) {
        double[] a = new double[shapes.length];
        for (int i = 0; i < shapes.length; i++) {
            if (shapes[i] != null) {
                a[i] = shapes[i].area();
            }
        }
        return a;
    }
}
