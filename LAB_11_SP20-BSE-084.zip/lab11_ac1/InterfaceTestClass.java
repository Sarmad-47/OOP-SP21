package lab11_ac1;

public class InterfaceTestClass {

    public static void main(String[] args) {
        EmployeeTask emp=new EmployeeTask("Max","5/11/2020",50000);
        InterfaceTestClass(emp);

    }

    public static void InterfaceTestClass(RegisterForExams as) {
        as.register();
    }

}
