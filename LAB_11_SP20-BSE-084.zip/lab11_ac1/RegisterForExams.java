
package lab11_ac1;


public interface RegisterForExams {
    public void register();
}
