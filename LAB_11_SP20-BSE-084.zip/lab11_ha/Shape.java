
package lab11_ha;

public interface Shape {
    public double perimeter();
    
}
