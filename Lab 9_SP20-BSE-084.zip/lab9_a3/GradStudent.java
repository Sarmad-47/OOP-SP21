
package lab9_a3;

public class GradStudent extends Student {
       @Override
     public void exam(){
       System.out.println("Giving Written paper!!");
    }
}
