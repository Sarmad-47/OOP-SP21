package lab9_a3;

public class ExamRun {

    public static void main(String[] args) {
        PhdStudent student1 = new PhdStudent();
        GradStudent student2 = new GradStudent();
        student1.exam();
        student2.exam();

    }

}
