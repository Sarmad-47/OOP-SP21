
package lab9_a3;


public class PhdStudent extends Student {
     @Override
     public void exam(){
        System.out.println("Giving Final Defense Presentation!");
    }
}
