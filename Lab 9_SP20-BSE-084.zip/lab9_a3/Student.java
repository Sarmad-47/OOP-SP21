
package lab9_a3;


public abstract class Student {
    public void exam(){
        System.out.println("Taking exam!!");
    }
}
