
package lab9_ha3;

import java.awt.Color;


public class ShapesRunner {

    public static void main(String[] args) {
        Circle circle=new Circle(6,Color.blue,Color.WHITE);
        Square square=new Square(4,Color.MAGENTA,Color.DARK_GRAY);
        Triangle triangle=new Triangle(3,Color.red,Color.BLACK);
        
        circle.draw();
        square.draw();
        triangle.draw();
    }
    
}
