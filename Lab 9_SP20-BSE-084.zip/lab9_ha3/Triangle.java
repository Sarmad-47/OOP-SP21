
package lab9_ha3;

import java.awt.Color;


public class Triangle extends Shapes {

    public Triangle(int numofLines, Color penColor, Color FillColor) {
        super(numofLines, penColor, FillColor);
    }

    @Override
    public void draw() {
        System.out.println("Drawing Triangle");
    }
    
}
