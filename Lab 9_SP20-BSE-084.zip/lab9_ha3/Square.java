
package lab9_ha3;

import java.awt.Color;


public class Square extends Shapes {

    public Square(int numofLines, Color penColor, Color FillColor) {
        super(numofLines, penColor, FillColor);
    }

    @Override
    public void draw() {
        System.out.println("Drawing Square");
    }
    
}
