
package lab9_ha3;

import java.awt.*;


public abstract class Shapes {
    protected int numofLines;
    protected Color penColor;
    protected Color FillColor;
    
    Shapes(int numofLines,Color penColor, Color FillColor){
        this.numofLines=numofLines;
        this.penColor=penColor;
        this.FillColor=FillColor;
        
    }
    public abstract void draw();
}
