
package lab9_a1;


public class ClockRunner {
    public static void main(String[] args) {
      ChildClock clock1=new ChildClock("19","45","50");
      clock1.Display();
      System.out.println("\n");
      
      ChildClock clock2=new ChildClock("22","15","30");
      clock2.Display();
    }
    
}
