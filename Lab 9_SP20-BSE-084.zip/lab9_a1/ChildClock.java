
package lab9_a1;


public class ChildClock extends Clock {
    
    public ChildClock(String hours, String min, String sec) {
        super(hours, min, sec);
    }
    
    @Override
    public void Display(){
        //displaying 24 hour format
        System.out.println("24 Hour Format:");
        super.Display();
        System.out.println("12 Hour Format:");
        //converting 24 hour format to 12 hour format.
         System.out.println("hr:min:sec");
        int hour1 = (int)hours.charAt(0) - '0';
        int hour2 = (int)hours.charAt(1)- '0';
        int tothour = hour1 * 10 + hour2;
        String a;
        if(tothour < 12)
            a="AM";
        else
            a="PM";
        tothour %= 12;
        if (tothour == 0) {
            System.out.print("12");
            System.out.print(":"+min+":"+sec);
        }
        else{
            System.out.print(tothour);
            System.out.print(":"+min+":"+sec);
        }
        System.out.println(" "+a);
    }
    
    
    
}
