
package lab9_a1;


public class Clock {
   String hours,min,sec;

    
    Clock(String hours,String min,String sec){
        this.hours=hours;
        this.min=min;
        this.sec=sec;
    }
    
      
    
    public void Display(){
       System.out.println("hr:min:sec");
        System.out.println(hours+" : "+min+" : "+sec);
    }
}
