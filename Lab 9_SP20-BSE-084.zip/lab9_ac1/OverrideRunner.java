package lab9_ac1;

public class OverrideRunner {

    public static void main(String[] args) {
        B subOb = new B(1, 2, 3);
        subOb.show(); // this calls show() in B

    }

}
