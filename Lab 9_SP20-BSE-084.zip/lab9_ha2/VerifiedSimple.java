
package lab9_ha2;

public class VerifiedSimple extends Simple {
    
    public VerifiedSimple(double num1, double num2) {
        super(num1, num2);
    }
    
    @Override
    public double add(){
        if(num1>0 && num2>0){
            return super.add(); //True and give us the result.
        }else{
            return 0;   //0 means false there is an error. 
        }
    }
    
    @Override
    public double sub(){
         if(num1>0 && num2>0){
            return super.sub(); //True and give us the result.
        }else{
            return 0;   //0 means false there is an error. 
        }
    }
    @Override
    public double mul(){
         if(num1>0 && num2>0){
            return super.mul(); //True and give us the result.
        }else{
            return 0;   //0 means false there is an error. 
        }
    }
    @Override
    public double div(){
         if(num1>0 && num2>0){
            return super.div(); //True and give us the result.
        }else{
            return 0;   //0 means false, there is an error. 
        }
    }
}
