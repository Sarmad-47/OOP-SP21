
package lab9_ha2;

public class SimpleRunner {
    public static void main(String[] args) {
       Simple sim=new Simple(-5,2);
        System.out.println("Simple version...");
        System.out.println("The sum is: "+sim.add());
        System.out.println("The difference of two numbers is : "+sim.sub());
        System.out.println("The product of two numbers is: "+sim.mul());
        System.out.println("Division = "+sim.div());
        
        
        System.out.println("\n\nVerfied Simple version.. ");
          VerifiedSimple versim=new VerifiedSimple(11,7);
          System.out.println("The sum is: "+versim.add());
        System.out.println("The difference of two numbers is : "+versim.sub());
        System.out.println("The product of two numbers is: "+versim.mul());
        System.out.println("Division = "+versim.div());
        
    }
    
  
    
    
}
