package lab9_ac2;

public class Overriderunner {

    public static void main(String[] args) {
        BasePlusCommEmployee b = new BasePlusCommEmployee("ali", "ahmed", "25-kkn", 100, 5.2, 25000);
        double earn = b.earnings();
        System.out.println("Earning of employee is = " + earn);
    }

}
